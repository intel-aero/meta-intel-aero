# AirMapSDK-Embedded

SUMMARY = "The AirMapSDK-Embedded package"

DESCRIPTION = "Airspace management services for safe drone operations. Retrieve local regulations, weather, create flight paths, send telemetry information and capture aircraft and emergency vehicle alerts during flight."

HOMEPAGE = "http://www.airmap.com"

LICENSE = "
–––––––––––––––
AIRMAPSDK-Intel
–––––––––––––––

Copyright (c) 2014-2016 AirMap, Inc.

By downloading or using the AirMap SDK, You agree to the AirMap Terms of Service (https://www.airmap.com/terms-conditions/) and SDK and License Agreement (https://www.airmap.com/developer-terms-conditions) and acknowledge that such terms govern Your use of and access to the AirMap SDK.

If You make any Contributions (defined below) to the AirMap SDK, You hereby grant AirMap a royalty-free, worldwide, transferable, sub-licensable, irrevocable and perpetual license to incorporate into AirMap services or the AirMap API or otherwise use and commercially exploit any Contributions. “Contribution” shall mean any work of authorship, including any modifications or additions to the AirMap SDK or derivative works thereof, that is submitted to AirMap by You."
