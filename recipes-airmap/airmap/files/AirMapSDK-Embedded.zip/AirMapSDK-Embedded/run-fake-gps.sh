echo Sending fake GPS data
gpsfake -c 1 fake-gps-data.log
