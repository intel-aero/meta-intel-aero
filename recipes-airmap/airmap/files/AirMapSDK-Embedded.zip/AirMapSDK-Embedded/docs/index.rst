.. airmap documentation master file, created by
   sphinx-quickstart on Sun Sept 18 11:35:50 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to AirMap's documentation!
======================================
.. include:: ../README.rst

Contents:

.. toctree::
   :maxdepth: 4

   airmap


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

