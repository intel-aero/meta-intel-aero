airmap Package
==================

:mod:`airdefs` Module
-------------------------

.. automodule:: airmap.airdefs
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`connect` Module
-------------------------

.. automodule:: airmap.connect
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`statusAPI` Module
--------------------------

.. automodule:: airmap.statusAPI
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`flightAPI` Module
--------------------------

.. automodule:: airmap.flightAPI
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`drone` Module
--------------------------

.. automodule:: airmap.drone
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`log` Module
--------------------------

.. automodule:: airmap.log
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`telemetryAPI` Module
--------------------------

.. automodule:: airmap.telemetryAPI
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`alertsAPI` Module
--------------------------

.. automodule:: airmap.alertsAPI
    :members:
    :undoc-members:
    :show-inheritance:

